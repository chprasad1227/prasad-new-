package com.ibm.issr.core.csv

/**
 * Helper class for working with CSV fields
 * @author ltclark
 *
 */
class CsvHelper {
	/**
	 * Takes the raw string value and encodes it so that it is OK to save as the contents
	 * of a CSV file cell.
	 * @param value
	 * @return The encoded value.
	 */
	public static String encodeCell( String value ) {
		if (value.contains('"') || value.contains("\n")) {
			String encoded = '"'
			value.each { letter ->
				encoded = encoded + letter
				if (letter == '"') {
					encoded = encoded + letter
				}
			}
			encoded = encoded + '"'
			return encoded
		} else {
			return value
		}
	}
}
