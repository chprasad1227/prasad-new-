package com.ibm.issr.core.plugin

/**
 * Class containing Plugin Helper functions.
 * @author ltclark
 *
 */
class PluginHelper {
	/**
	 * Immediately abort the plugin because of a failure condition described by the message.
	 * This actually throws a message.  The message is displayed to the output as an 'error'
	 * message, but no stack trace is thrown.
	 * @param msg
	 */
	static public void abortPlugin( String msg ) {
		throw new AbortPluginException(msg)
	}
}
