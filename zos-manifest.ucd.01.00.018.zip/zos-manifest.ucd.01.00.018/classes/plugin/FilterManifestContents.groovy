package plugin

import plugin.impl.FilterManifestContentsImpl

import com.ibm.issr.core.log.Logger

class FilterManifestContents extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new FilterManifestContents()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		def pdsMapping = inProps.pdsMapping
		def custProperties = inProps.custProperties
		def versionName = inProps.versionName
		def componentName = inProps.componentName
		def resourceId = inProps.resourceId
		
		// Display a summary of what this plugin is going to do
		Logger.info "Filter Manifest Contents"
		Logger.info "   pdsMapping = ${pdsMapping}"
		Logger.info "   custProperties = ${custProperties}"
		Logger.info "   versionName = ${versionName}"
		Logger.info "   componentName = ${componentName}"
		Logger.info "   resourceId = ${resourceId}"
		super.displayParameters()
		
		FilterManifestContentsImpl filter = new FilterManifestContentsImpl()
		String manifestFilename = filter.calculateManifestFilename(versionName, resourceId)
		filter.loadManifestFromFile(manifestFilename)
		filter.applyFilter(pdsMapping,custProperties)
		filter.saveManifestToFile(manifestFilename)
	}
}
