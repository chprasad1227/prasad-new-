package plugin

import plugin.impl.FilterManifestContentsImpl
import plugin.impl.GenerateArtifactInfoImpl;
import plugin.impl.ManifestUtilities;

import com.ibm.issr.core.log.Logger

class GenerateArtifactInfo extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new GenerateArtifactInfo()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		String loopType = inProps.loopType
		String srcDatasetName = inProps.srcDatasetName
		String memberName = inProps.memberName
		String deployTypeName = inProps.deployTypeName
		String custProperties = inProps.custProperties
		String templateText = inProps.templateText
		
		String versionName = inProps.versionName
		String componentName = inProps.componentName
		String resourceId = inProps.resourceId
		
		// Display a summary of what this plugin is going to do
		Logger.info "Generate Artifact Information from Current Manifest File"
		Logger.info "   srcDatasetName = ${srcDatasetName}"
		Logger.info "   memberName = ${memberName}"
		Logger.info "   deployTypeName = ${deployTypeName}"
		Logger.info "   custProperties = ${custProperties}"
		Logger.info "   templateText = ${templateText}"
		Logger.info "   loopType = ${loopType}"
		Logger.info "   versionName = ${versionName}"
		Logger.info "   componentName = ${componentName}"
		Logger.info "   resourceId = ${resourceId}"
		super.displayParameters()

		String manifestFilename = ManifestUtilities.calculateManifestFilename(versionName, resourceId)
		GenerateArtifactInfoImpl genArtifactInfoImpl = new GenerateArtifactInfoImpl()
		
		genArtifactInfoImpl.loadManifestFromFile(manifestFilename)
		
		String results = genArtifactInfoImpl.generateFilter(loopType, srcDatasetName, memberName, deployTypeName, custProperties, templateText)
		
		Logger.debug "Results = ${results}"
		
		outProps.put('text', results)
		def xmlNodeManifest = ManifestUtilities.loadManifestFromFile(manifestFilename)
		}
}
