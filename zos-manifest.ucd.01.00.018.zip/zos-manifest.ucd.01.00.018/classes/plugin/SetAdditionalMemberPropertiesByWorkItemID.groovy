package plugin

import plugin.impl.SetAdditionalMemberPropertiesByWorkItemIDImpl

import com.ibm.issr.core.log.Logger

class SetAdditionalMemberPropertiesByWorkItemID extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new SetAdditionalMemberPropertiesByWorkItemID()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		def additionalAttributesIndexedByWorkItemId = inProps.additionalAttributesIndexedByWorkItemId
		def versionName = inProps.versionName
		def componentName = inProps.componentName
		def resourceId = inProps.resourceId
		
		// Display a summary of what this plugin is going to do
		Logger.info "Set Additional Member Properties By Work Item ID"
		Logger.info "   additionalAttributesIndexedByWorkItemId = ${additionalAttributesIndexedByWorkItemId}"
		Logger.info "   versionName = ${versionName}"
		Logger.info "   componentName = ${componentName}"
		Logger.info "   resourceId = ${resourceId}"
		super.displayParameters()
		
		SetAdditionalMemberPropertiesByWorkItemIDImpl impl = new SetAdditionalMemberPropertiesByWorkItemIDImpl()
		String manifestFilename = impl.calculateManifestFilename(versionName, resourceId)
		impl.loadManifestFromFile(manifestFilename)
		impl.addAttributes(additionalAttributesIndexedByWorkItemId)
		impl.saveManifestToFile(manifestFilename)
	}
}
