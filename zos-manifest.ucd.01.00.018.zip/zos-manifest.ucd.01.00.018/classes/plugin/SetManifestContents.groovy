package plugin

import plugin.impl.FilterManifestContentsImpl
import plugin.impl.ManifestUtilities;

import com.ibm.issr.core.log.Logger

class SetManifestContents extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new SetManifestContents()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		String contents = inProps.contents
		def versionName = inProps.versionName
		def componentName = inProps.componentName
		def resourceId = inProps.resourceId
		
		// Display a summary of what this plugin is going to do
		Logger.info "Get Manifest Contents"
		Logger.info "   contents = ${contents}"
		Logger.info "   versionName = ${versionName}"
		Logger.info "   componentName = ${componentName}"
		Logger.info "   resourceId = ${resourceId}"
		super.displayParameters()
		
		String manifestFilename = ManifestUtilities.calculateManifestFilename(versionName, resourceId)
		(new File(manifestFilename)).text = contents
	}
}
