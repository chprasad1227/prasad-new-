package plugin

import plugin.impl.FilterManifestContentsImpl
import plugin.impl.ManifestUtilities;

import com.ibm.issr.core.log.Logger

class BackupDownloadedFiles extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new BackupDownloadedFiles()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		def versionName = inProps.versionName
		def componentName = inProps.componentName
		def resourceId = inProps.resourceId
		
		// Display a summary of what this plugin is going to do
		Logger.info "Backup Downloaded zOS files"
		Logger.info "   versionName = ${versionName}"
		Logger.info "   componentName = ${componentName}"
		Logger.info "   resourceId = ${resourceId}"
		super.displayParameters()
		
		String zosDirectory = ManifestUtilities.calculateZosDownloadDirectory(versionName, resourceId)
		Logger.debug "zOS download directory is '${zosDirectory}'"
		String backupDirectory = ManifestUtilities.calculateBackupDirectory(versionName, resourceId)
		Logger.debug "zOS backup directory is '${backupDirectory}'"

		File zosDirectoryHandle = new File(zosDirectory)
		File backupDirectoryHandle = new File(backupDirectory)
		
		if (! backupDirectoryHandle.exists()) {
			backupDirectoryHandle.mkdir()
		}
		
		// Iterate the files in the zos directory
		zosDirectoryHandle.eachFile { File file ->
			if (file.isFile()) {
				Logger.debug "Copying file ${file.name}"
				
				def input = file.newDataInputStream()
				def output = (new File(backupDirectory,file.name)).newDataOutputStream()
				output << input
				output.close()
				input.close()
			}
		}
	}
}
