package plugin

import plugin.impl.FilterManifestContentsImpl
import plugin.impl.ManifestUtilities;

import com.ibm.issr.core.log.Logger

class GetManifestContents extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new GetManifestContents()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		def versionName = inProps.versionName
		def componentName = inProps.componentName
		def resourceId = inProps.resourceId
		
		// Display a summary of what this plugin is going to do
		Logger.info "Get Manifest Contents"
		Logger.info "   versionName = ${versionName}"
		Logger.info "   componentName = ${componentName}"
		Logger.info "   resourceId = ${resourceId}"
		super.displayParameters()
		
		String manifestFilename = ManifestUtilities.calculateManifestFilename(versionName, resourceId)
		String contents = (new File(manifestFilename)).text
		
		Logger.info "*** CONTENTS ***"
		Logger.info contents
		
		outProps.put( 'contents', contents)
	}
}
