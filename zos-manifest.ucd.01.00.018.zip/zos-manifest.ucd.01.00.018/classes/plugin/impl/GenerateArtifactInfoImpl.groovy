package plugin.impl

import com.ibm.issr.core.log.Logger

class GenerateArtifactInfoImpl extends CoreClassForUpdatingManifestFile {
	/**
	 * Apply the filter and generate the output string based on the 'templateText'.
	 * @param loopType 'Member' or 'PDS'
	 * @param srcDatasetName Filter to use on the source dataset/container name. Container can be data set, directory or generic artifact group. 
	 * Java regular expression matching is used if the filter starts and ends with a forward slash (/). For example, specify /.*LOAD/ to match 
	 * any text that ends with LOAD. If the filter is not a regular expression, exact matching is used.
	 * @param memberName Filter to use on resource name. Resource can be data set member, file or generic artifact. 
	 * Java regular expression matching is used if the filter starts and ends with a forward slash (/). For example, 
	 * specify /.*LOAD/ to match any text that ends with LOAD. If the filter is not a regular expression, exact matching is used.
	 * @param deployTypeName Filter to use on the deploy type. Java regular expression matching is used if the filter starts and 
	 * ends with a forward slash (/). For example, specify /.*LOAD/ to match any text that ends with LOAD. If the filter is not a 
	 * regular expression, exact matching is used.
	 * @param custProperties Specify a list of custom properties filters, separated by newline characters. Use the following format: 
	 * propertyName=valueFilter. A property without valueFilter selects all artifacts that have that property. Java regular expression 
	 * matching is used if the filter starts and ends with a forward slash (/).
	 * If valueFilter is not a regular expression, exact matching is used. For example, developer=Martin matches artifacts where value of the developer property is Martin.
	 * @param templateText Specify the template to use to generate text.  See plugin.xml for the full details.
	 * @return Returns the string generated based on the filtered containers and members applied to the template.
	 */
	public String generateFilter( String loopType, String srcDatasetName, String memberName, String deployTypeName, String custProperties, String templateText ) {
		String generatedFilter = ''
		
		if (! loopType.equalsIgnoreCase('member')) {
			notImplementedYet("looptype of '${loopType}'")
		}
		
		// Filter containers
		// List of container Nodes to be deleted
		List containersToDelete = []
		manifest.container.each { Node container ->
			if (! ManifestContentsHelper.matchesStringFilter( container.@name, srcDatasetName, false )) {
				containersToDelete << container
			}
		}
		containersToDelete.each { Node container ->
			manifest.remove(container)
		}
		
		// Filter member resources
		manifest.container.each { Node container ->
			List resourcesToDelete = []
			container.resource.each { Node resource ->
				if (! (ManifestContentsHelper.matchesStringFilter(resource.@name, memberName, false) && ManifestContentsHelper.matchesStringFilter( getDeployType(resource), deployTypeName, false ) &&
					ManifestContentsHelper.matchesPropertyFilter( resource, custProperties ))) {
					resourcesToDelete << resource
				} 
			}
			resourcesToDelete.each { Node resource ->
				container.remove(resource)
			}
		}
		
		// Apply the resulting list to the template
		iterateResourceMembers { Node container, Node resource ->
			generatedFilter = generatedFilter + applyTemplate( templateText, container, resource )
			println "${container.@name}(${resource.@name})"
		}
		
		Logger.debug "Generated filter is '${generatedFilter}'"
		
		
		return generatedFilter
	}
	
	/**
	 * Returns the deployType value of the given member resource node.  If the attribute isn't
	 * defined, then this returns an empty string.
	 */
	private String getDeployType( Node resource ) {
		def attributes = resource.attributes()
		if (attributes.containsKey('deployType')) {
			return resource.@deployType
		} else {
			return ''
		}
	}
	
	/**
	 * Applies the template tot he container and resource member.
	 * @param templateText The template
	 * @param container The container.
	 * @param resource The resource member.
	 * @return The populated template value.
	 */
	private String applyTemplate( String templateText, Node container, Node resource ) {
		// loop through finding ${...} values
		int offset = 0
		String retval = ''
		while (offset >=0 && offset < templateText.length()) {
			int nextTokenOffset = templateText.indexOf('${', offset)
			if (nextTokenOffset < 0) {
				// No more tokens - use the rest of the string
				retval = retval + templateText.substring(offset)
				offset = -1
			} else {
				// found another token start value - find the end token
				int nextEndTokenOffset = templateText.indexOf('}',offset+2)
				if (nextEndTokenOffset < 0) {
					// No more tokens - use the rest of the string
					retval = retval + templateText.substring(offset)
					offset = -1
				} else {
					// Found a token!!
					// try to find a value for the token
					String tokenName = templateText.substring(nextTokenOffset+2,nextEndTokenOffset)
					// add the string and token lookup to retval
					retval = retval + templateText.substring(offset,nextTokenOffset) + calculateTokenValue( tokenName, container, resource )
					offset = nextEndTokenOffset + 1
				}
			}
		}
		return retval
	}
	
	/**
	 * Calculate the value of a named token given the contenxt of a container and resource.
	 * @param tokenName The string token value, such as 'member'
	 * @param container The container from the manifest.
	 * @param resource The member file resource from the manifest.
	 * @return Returns the value of the token.  If the token has no value, then it returns the
	 * token name with delimeters.
	 */
	private String calculateTokenValue( String tokenName, Node container, Node resource ) {
		String result = '${' + tokenName + '}'
		switch (tokenName.toLowerCase()) {
			case 'member':
				result = resource.@name
				break
			case 'sourcedataset':
				result = container.@name
				break
			case 'deploytype':
				result = resource.@deployType
				break
			default:
				Node property = ManifestContentsHelper.lookupPropertyByName( resource, tokenName )
				if (property) {
					result = property.@value
				}
				break
		}
		return result
	}
	
	/**
	 * Iterates the resource members of the manifest with a closure.
	 * @param iterator Iteration closure, which takes two parameters 'Node container, Node resource'
	 */
	private void iterateResourceMembers( Closure iterator ) {
		manifest.container.each { Node container ->
			container.resource.each { Node resource ->
				iterator( container, resource )
			}
		}
	}
	
	private void notImplementedYet( String msg ) {
		throw new Exception( "${msg} is not implemented by the plugin yet")
	}
}
