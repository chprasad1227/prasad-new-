package plugin.impl

import groovy.util.Node;

/**
 * Utility and common functions for managing the contents of a manifest which 
 * is loaded into memory as a set of XML nodes.
 * @author ltclark
 *
 */
class ManifestContentsHelper {
	
	
	/**
	 * Looks up the property value of the resource member node by name.
	 * @param resource The resource member node.
	 * @param name The name of the child property.
	 * @return Returns the property's value or an empty string if not found.
	 */
	static String getPropertyValueByName( Node resource, String name ) {
		Node property = ManifestContentsHelper.lookupPropertyByName(resource, name)
		if (property) {
			return property.@value
		} else {
			return ''
		}
	}
	
	
	/**
	 * Looks up the child property of the resource by name.
	 * @param resource The member resource node.
	 * @param name The case sensitive name.
	 * @return Returns the Property node if found, or null if not found.
	 */
	static Node lookupPropertyByName( Node resource, String name ) {
		Node retval = null
		resource.property.each { Node property ->
			if (property.@name == name) {
				retval = property
			}
		}
		return retval
	}

	
	/**
	 * Does the string value match the string filter clause.
	 * @param value The string value to test.
	 * @param filterClause The filter clause.  If this is empty, then there is no clause, so all string values match.
	 * If this starts and ends with a forward slash (/), then wildcard matching is used.  Otherwise, it looks for exact match.
	 * @param testIfEmptyFilterClause If true, then compare the value and filterClause even if the filterClause is empty.  Otherwise,
	 * skip the test if the filter clause is empty.
	 * @return Is it a match?
	 */
	static boolean matchesStringFilter( String value, String filterClause, boolean testIfEmptyFilterClause ) {
		filterClause = filterClause.trim()
		if (! filterClause) {
			if (testIfEmptyFilterClause) {
				return (value == filterClause)
			} else {
				// no filter clause - so it matches
				return true
			}
		} else if (filterClause.startsWith('/') && filterClause.endsWith('/')) {
			// wildcard match
			return value ==~ /${filterClause.substring(1,filterClause.length()-1)}/
		} else {
			// exact match
			return (value == filterClause)
		}
	}
	
	/**
	 * Does the resource member meet the property filters?
	 * @param resource The resource member node.
	 * @param propertyFilter Property filter, which is a multiple line string.  Each string is
	 * a name=value pair where name is the name of a property and value is a wildcard string
	 * (that starts and ends with /) or a fixed, case sensitive string.
	 * @return Is it a match?
	 */
	static boolean matchesPropertyFilter( Node resource, String propertyFilter ) {
		boolean isMatch = true
		if (propertyFilter) {
			propertyFilter.eachLine { String line, lineNumber ->
				line = line.trim()
				if (line) {
					int equalOffset = line.indexOf('=')
					if (equalOffset < 0) {
						throw new Exception( "The property filter should be formated as propertyName=value, but line number ${lineNumber+1} contains '${line}'")
					}
					String propertyName = line.substring(0,equalOffset).trim()
					String filterValue = line.substring(equalOffset+1).trim()
					if (! ManifestContentsHelper.matchesStringFilter( ManifestContentsHelper.getPropertyValueByName(resource, propertyName), filterValue, true )) {
						isMatch = false
					}
				}
			}
		}
		return isMatch
	}

}
