package plugin.impl

/**
 * This is a common base class for plugin step implementations that read, update and save
 * changes to a manifest.
 * @author ltclark
 *
 */
class CoreClassForUpdatingManifestFile {
	// This is the manifest in memory as parsed XML contents (java.util.Node)
	protected Node manifest
	
	/**
	 * Calculates and returns the relative name (relative to the Working Directory) for
	 * the manifest filename.
	 * @param versionName This is the name of the Component Version.  This is part of the calculation.
	 * @param resourceId This is the name of the Component Resource.  This is part of the calculation.
	 */
	public String calculateManifestFilename( String versionName, String resourceId ) {
		return ManifestUtilities.calculateManifestFilename(versionName, resourceId)
	}
	
	/**
	 * Loads a manifest from a named file into the class instance.
	 * @param manifestFilename Name of the file, relative to the current working directory.
	 */
	public void loadManifestFromFile( String manifestFilename ) {
		manifest = ManifestUtilities.loadManifestFromFile(manifestFilename)
	}
	
	/**
	 * Saves the current manifest definition to the named file.
	 * @param manifestFilename Name of the output file, relative to the current working directory.
	 */
	public void saveManifestToFile( String manifestFilename ) {
		ManifestUtilities.saveManifestToFile(manifestFilename, manifest)
	}
	
	/**
	 * Loads the manifest definition from a string instead of a file.  This is very
	 * useful for unit testing.
	 * @param manifestContents This string IS a Manifest XML.
	 */
	public void loadManifestFromString( String manifestContents ) {
		manifest = ManifestUtilities.loadManifestFromString(manifestContents)
	}
	
	/**
	 * Returns the current manifest as an XML string.  This is very useful for Unit Testing.
	 */
	public String getManifestAsString() {
		return ManifestUtilities.getManifestAsString( manifest )
	}

}
