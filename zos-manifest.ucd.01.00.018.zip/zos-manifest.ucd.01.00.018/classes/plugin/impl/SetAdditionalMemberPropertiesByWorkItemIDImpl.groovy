package plugin.impl

import com.ibm.issr.core.log.Logger;

import groovy.xml.*

/**
 * Implementation of the SetAdditionalMemberPropertiesByWorkItemID plugin step.
 * @author ltclark
 *
 */
class SetAdditionalMemberPropertiesByWorkItemIDImpl extends CoreClassForUpdatingManifestFile {
	
	/**
	 * Add the attributes to the Manifest.
	 * @param additionalAttributesIndexedByWorkItemId JSON string containing the attribute mappings.
	 */
	public void addAttributes( String additionalAttributesIndexedByWorkItemId ) {
		// Parse the indexed attributes JSON
		def attributeMap = new groovy.json.JsonSlurper().parseText( additionalAttributesIndexedByWorkItemId )

		manifest.container.each { Node containerNode ->
			containerNode.resource.each { Node resourceNode ->
				// 'resourceNode' is one member
					
				// This is the list of attributees to define.  Key is the attribute name and the value is the value.
				def newProperties = [:]
			
				// Find the  new properties for the member
				resourceNode.property.each { Node propertyNode ->
					if (propertyNode.@name=='WorkItemId') {
						String workItems = propertyNode.@value
						workItems.tokenize(',').each { String workItemId ->
							workItemId = workItemId.trim()
							if (workItemId) {
								if (attributeMap.containsKey(workItemId)) {
									attributeMap[workItemId].each { String propertyName, String propertyValue ->
										newProperties[propertyName] = propertyValue
									}
								}
							}
						}
					}
				}
				
				// Add the new properties
				newProperties.each { String propertyName, String propertyValue ->
					defineProperty( resourceNode, propertyName, propertyValue )
				}
				
			}
		}
	}
	
	/**
	 * Defines the property for the given member resourceNode.  If the property already exists, then this updates it.  If
	 * the property doesn't exist, then this adds it.
	 * @param resourceNode The resourceNode for a member of the manifest.
	 * @param propertyName The name of the property
	 * @param propertyValue The value of the property
	 */
	private void defineProperty( Node resourceNode, String propertyName, String propertyValue ) {
		// Try to update the properties first
		boolean existingProperty = false
		resourceNode.property.each { Node propertyNode ->
			if (propertyNode.@name == propertyName) {
				existingProperty = true
				propertyNode.@value = propertyValue
			}
		}
		
		if (! existingProperty) {
			// Create and add the new Property node
			new Node( resourceNode, 'property', [name:propertyName, value:propertyValue] )
		}
	}
}
