package plugin.impl

/**
 * Utility functions for managing the manifest file(s).  See the class ManifestContentsHelper for
 * utilities for managing a manifest object tree in memory.
 * @author ltclark
 *
 */
class ManifestUtilities {
	
	/**
	 * Calculates and returns the relative name (relative to the Working Directory) for
	 * the manifest filename.
	 * @param versionName This is the name of the Component Version.  This is part of the calculation.
	 * @param resourceId This is the name of the Component Resource.  This is part of the calculation.
	 */
	public static String calculateManifestFilename( String versionName, String resourceId ) {
		return "./${resourceId.trim()}/${versionName.trim()}/packageManifest.xml"
	}
	
	/**
	 * Calculates and returns the relative directory name (relative to the Working Directory) for
	 * where the zOS files were downloaded.
	 * @param versionName This is the name of the Component Version.  This is part of the calculation.
	 * @param resourceId This is the name of the Component Resource.  This is part of the calculation.
	 */
	public static String calculateZosDownloadDirectory( String versionName, String resourceId ) {
		return "./${resourceId.trim()}/${versionName.trim()}"
	}
	
	/**
	 * Calculates and returns the relative name for where the zOS files will be backed up/restored
	 * from.
	 * @param versionName This is the name of the Component Version.  This is part of the calculation.
	 * @param resourceId This is the name of the Component Resource.  This is part of the calculation.
	 */
	public static String calculateBackupDirectory( String versionName, String resourceId ) {
		return "./${resourceId.trim()}/backup"
	}

	/**
	 * Calculates and returns the relative name (relative to the Working Directory) for
	 * the BACKUP copy of the manifest filename as per the 'Save Copy...' and 'Restore...' steps
	 * @param versionName This is the name of the Component Version.  This is part of the calculation.
	 * @param resourceId This is the name of the Component Resource.  This is part of the calculation.
	 */
	public static String calculateBackupManifestFilename( String versionName, String resourceId ) {
		return "./${resourceId.trim()}/${versionName.trim()}/packageManifest.backup"
	}
	
	/**
	 * Loads a manifest from a named file into an XML Node tree, which is returned.
	 * @param manifestFilename Name of the file, relative to the current working directory.
	 */
	public static def loadManifestFromFile( String manifestFilename ) {
		return new XmlParser().parse(manifestFilename)
	}
	
	/**
	 * Saves the manifest definition to the named file.
	 * @param manifestFilename Name of the output file, relative to the current working directory.
	 * @param xmlNodeManifest A manifest in an XML Node object tree.
	 */
	public static void saveManifestToFile( String manifestFilename, def xmlNodeManifest ) {
		PrintWriter xmlOut = new PrintWriter(new FileWriter(manifestFilename))
		xmlOut.println '<?xml version="1.0"?>'
		new XmlNodePrinter(xmlOut).print(xmlNodeManifest)
		xmlOut.flush()
		xmlOut.close()
	}
	
	/**
	 * Loads the manifest definition from a string instead of a file.  This is very
	 * useful for unit testing.  Returns the XML Node object tree for the manifest.
	 * @param manifestContents This string IS a Manifest XML.
	 */
	public static def loadManifestFromString( String manifestContents ) {
		return new XmlParser().parseText(manifestContents)
	}
	
	/**
	 * Returns the manifest as an XML string.  This is very useful for Unit Testing.
	 * @param xmlNodeManifest A manifest in an XML Node object tree.
	 */
	public static String getManifestAsString( def xmlNodeManifest ) {
		StringWriter xmlOutWriter = new StringWriter()
		PrintWriter xmlOut = new PrintWriter(xmlOutWriter)
		xmlOut.println '<?xml version="1.0"?>'
		new XmlNodePrinter(xmlOut).print(xmlNodeManifest)
		return xmlOutWriter.toString()
	}

}
