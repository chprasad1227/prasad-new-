package plugin.impl

import com.ibm.issr.core.log.Logger;

import groovy.xml.*

/**
 * Implementation of the FilterManifestContents plugin step.
 * @author ltclark
 *
 */
class FilterManifestContentsImpl extends CoreClassForUpdatingManifestFile {
	// PDS Mapping entries that don't have a wildcard.  Key = source PDS.  Value = target PDS
	private def pdsMapping_nonWildcard = [:]
	// PDS Mapping entries that HAVE a wildcard.  Key = source PDS.  Value = target PDS
	private def pdsMapping_wildcard = [:]
	
	/**
	 * Is the given pds defined within the source PDS's in the PdsMapping (see prepareToHandlePdsMapping())
	 * @param pds The name of a pds, such as "a.b.c"
	 * @return True if the pds is part of the mapping, otherwise false.
	 */
	private boolean isPdsInPdsMapping( String pds ) {
		pds = pds.trim()
		if (pdsMapping_nonWildcard.containsKey(pds)) {
			return true
		} else {
			// check to see if there is a wildcard mapping
			boolean foundEntry = false
			pdsMapping_wildcard.keySet().each { String wildCardPattern ->
				if (pds ==~ wildCardPattern) {
					foundEntry = true
				}
			}
			return foundEntry
		}
	}
	
	/**
	 * Parses and organizes the information in the pdsMapping.
	 * @param pdsMapping This is a PDS Mapping as defined by the standard zOS 'Deploy Data Sets' definition.
	 * If ANY pds container in the manifest does NOT have at least one entry in the pdsMapping, then it
	 * is removed from the manifest.
	 */
	private void prepareToHandlePdsMapping( String pdsMapping ) {
		if (pdsMapping) {
			pdsMapping = pdsMapping.trim()
			def pdsMappingLines = pdsMapping.readLines()
			pdsMappingLines.each { String pdsMappingLine ->
				if (pdsMappingLine.trim().length() > 0) {
					def tokens = pdsMappingLine.tokenize(',')
					println tokens[0]
					println tokens[1]
					
					String srcPds = tokens[0].trim()
					if (srcPds) {
						// Found a source PDS.  Is it fixed or does it have a '*' wildcard
						if (srcPds.contains('*')) {
							// Source PDS has wildcards
							// Convert the string from a psuedo-wildcard to a true wildcard expression
							String srcPattern = ~srcPds.replaceAll(/\./, "\\.").replaceAll(/\*/, "\\.\\*");
							if (! pdsMapping_wildcard.containsKey(srcPattern)) {
								pdsMapping_wildcard.put(srcPattern, tokens[1])
							}
						} else {
							// Source PDS doesn't have wildcards
							if (! pdsMapping_nonWildcard.containsKey(srcPds)) {
								pdsMapping_nonWildcard.put(srcPds, tokens[1])
							}
						}
					}
				}
			}
		}
	}
	
	/**
	 * Applies a set of filters to the manifest.  The manifest MUST be loaded before calling this step.  See the
	 * parameters for the different filters that are applied.
	 * @param pdsMapping Optional (may be null or blank) This is a PDS Mapping as defined by the standard zOS 'Deploy Data Sets' definition.
	 * If ANY pds container in the manifest does NOT have at least one entry in the pdsMapping, then it
	 * is removed from the manifest.
	 * @param custProperties Optional (may be null or blank).  Specify a list of custom properties filters, separated 
	 * by newline characters. Use the following format: propertyName=valueFilter. A property without valueFilter selects 
	 * all artifacts that have that property. Java regular expression matching is used if the filter starts and ends 
	 * with a forward slash (/). For example, specify developer=/M.* / to match artifacts with a developer property 
	 * where the value of the property starts with M.  If valueFilter is not a regular expression, exact matching is used. 
	 * For example, developer=Martin matches artifacts where value of the developer property is Martin.
	 */
	public void applyFilter( String pdsMapping, String custProperties ) {
		if (pdsMapping) {
			pdsMapping = pdsMapping.trim()
		}
		if (custProperties) {
			custProperties = custProperties.trim()
		}
		
		prepareToHandlePdsMapping( pdsMapping )
		
		// Queue up a list of the containers that need to be deleted instead of deleting them while iterating the container list
		List containersToDelete = []
		
		manifest.container.each { Node containerNode ->
			String containerNodeName = containerNode.@name
			boolean deleteContainer = false
			if (pdsMapping) {
				if (! isPdsInPdsMapping( containerNodeName )) {
					Logger.debug "No PdsMap entry found for ${containerNodeName}"
					deleteContainer = true
				}
			}
			if (deleteContainer) {
				containersToDelete << containerNode
			} else if (custProperties) {
				// queue up list of child resource nodes to delete
				List resourcesToDelete = []
				containerNode.resource.each { Node resourceNode ->
					if (! ManifestContentsHelper.matchesPropertyFilter(resourceNode, custProperties)) {
						resourcesToDelete << resourceNode
					}
				}
				resourcesToDelete.each { Node resourceNode ->
					containerNode.remove(resourceNode)
				}
			}
		}
		
		// Delete the queued up list of containers
		containersToDelete.each { containerNode ->
			manifest.remove(containerNode)
		}
		
	}
}
