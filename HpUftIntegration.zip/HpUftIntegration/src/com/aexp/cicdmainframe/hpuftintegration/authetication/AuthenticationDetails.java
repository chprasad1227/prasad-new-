package com.aexp.cicdmainframe.hpuftintegration.authetication;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.log4j.Logger;

import com.aexp.cicdmainframe.hpuftintegration.common.HPUFTIntegrationConstants;
import com.aexp.cicdmainframe.hpuftintegration.common.PropertiesCache;
import com.aexp.cicdmainframe.hpuftintegration.exception.HPUFTIntegrationException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.core.util.Base64;

public class AuthenticationDetails  {

	static final Logger logger = Logger.getLogger(AuthenticationDetails.class);

	private static  AuthenticationDetails authenticationDetails;	

	private Map<String, String> authentcateDetailsMap = null;

	private  AuthenticationDetails() {

	}
	public static AuthenticationDetails getInstance() {
		if(authenticationDetails==null) {
			authenticationDetails = new AuthenticationDetails();
		}
		return authenticationDetails;
	}

	/**
	 * Invokes Authentication Service
	 * using username and password 
	 * stores LWSSO_COOKIE_VALUE into authenticationMap
	 * @return authenticationMap
	 */
	public Map<String, String> getAuthenticateDetails() throws HPUFTIntegrationException {
		logger.info("Invoking Authentication.....");
		if(authentcateDetailsMap == null) {
			authentcateDetailsMap = new HashMap<String, String>();
		}
		String username = PropertiesCache.getInstance().getProperty(HPUFTIntegrationConstants.USERNAME);		
		String password = PropertiesCache.getInstance().getProperty(HPUFTIntegrationConstants.PASSWORD);		
		try {			
			ClientResponse response = null;
			if(username!=null && password!=null ) {
				String plainCreds = username + ":" + password;		
				byte[] plainCredsBytes = plainCreds.getBytes();
				byte[] base64CredsBytes = Base64.encode(plainCredsBytes);
				String base64CredBytes = new String(base64CredsBytes);		
				String credentials = base64CredBytes;
				authentcateDetailsMap.put(HPUFTIntegrationConstants.CREDENTIALS, credentials);
				String authHeader = "Basic " + credentials;			
				String authUrl = PropertiesCache.getInstance().getProperty(HPUFTIntegrationConstants.AUTHENTICATION_URL);
				logger.info("Invoking Authentication.."+authUrl+"\tauthHeader..\t"+authHeader);
				if(authUrl=="" || authUrl==null) {
					throw new HPUFTIntegrationException("Authentication URL is null");
				}
				/* Invoking Authentication Service*/
				ClientConfig clientConfig = new DefaultClientConfig();			
				Client restClient = Client.create(clientConfig); 

				WebResource webResource = restClient.resource(authUrl);   
				response = webResource.header("Authorization",authHeader )		
				.get(ClientResponse.class);
			} else {
				throw new HPUFTIntegrationException("userName  or Password is null");
			}	
			if (response.getStatus() != ClientResponse.Status.OK.getStatusCode()) {
				//logger.error("Failed : HTTP error code : "+ response.getStatusLine().getStatusCode());
				throw new RuntimeException("Failed for Authentication: HTTP error code :" + response.getStatus());
			}
			MultivaluedMap<String, String> headers = response.getHeaders();			
			String cookieValue = null;
			for (Entry<String, List<String>> header : headers.entrySet()) {
				logger.info("Key : " + header.getKey()+ " ,Value : " + header.getValue());
				if ("Set-Cookie".equalsIgnoreCase(header.getKey())) {
					for(String cookieVal : header.getValue()) { 
						cookieValue = cookieVal;					
						break;
					}
				}
			}
			/* Storing the LWSSO_COOKIE_VALUE into authenticationMap */
			String[] lwSsoCookie = cookieValue.split("=");
			if ("LWSSO_COOKIE_KEY".equalsIgnoreCase(lwSsoCookie[0])) {
				logger.info("LWSSO_COOKIE_VALUE:: "+cookieValue); 
				logger.debug("LWSSO_COOKIE_VALUE:: "+cookieValue); 
				authentcateDetailsMap.put("LWSSO_COOKIE_VALUE", cookieValue);
			}
		} catch (Exception e) {
			logger.error("Exception in Authentication"+e);
			logger.debug("Exception in Authentication"+e);

			throw new HPUFTIntegrationException(e.getMessage());
		}
		return authentcateDetailsMap;
	}

}
