package com.aexp.cicdmainframe.hpuftintegration.response;


public class BuildVerificationSuiteExecutionResponse {

	private Entity entity;
	public BuildVerificationSuiteExecutionResponse() {
		super();
		
	}
	
	public Entity getEntity() {
		return entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}

	@Override
	public String toString() {
		return "BuildVerificationSuiteExecutionResponse [entity=" + entity + "]";
	}
}
