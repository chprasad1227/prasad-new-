package com.aexp.cicdmainframe.hpuftintegration.response;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Entity")
public class Entity implements Serializable
{
   private static final long serialVersionUID = 1L;

	@XmlElement(name="RelatedEntities")
	private String RelatedEntities;
	
	@XmlElement(name="Fields")
    private Fields Fields;

	@XmlAttribute(name="Type")
	private String Type;

    
    public Entity() {
		super();
	}
	public String getRelatedEntities ()
    {
        return RelatedEntities;
    }    
    public void setRelatedEntities (String RelatedEntities)
    {
        this.RelatedEntities = RelatedEntities;
    }
    public Fields getFields ()
    {
        return Fields;
    }    
    public void setFields (Fields Fields)
    {
        this.Fields = Fields;
    }
    public String getType ()
    {
        return Type;
    }
   
    public void setType (String Type)
    {
        this.Type = Type;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [RelatedEntities = "+RelatedEntities+", Fields = "+Fields+", Type = "+Type+"]";
    }
}