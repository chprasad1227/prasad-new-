package com.aexp.cicdmainframe.hpuftintegration.response;


public class StartRunProcedureResponse {

	private Entity entity;
	public StartRunProcedureResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Entity getEntity() {
		return entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}

	@Override
	public String toString() {
		return "StartRunProcessResponse [entity=" + entity + "]";
	}
	
	
	

}
