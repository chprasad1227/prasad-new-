package com.aexp.cicdmainframe.hpuftintegration.response;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Field")
public class Field implements Serializable
{
   
	private static final long serialVersionUID = 1L;
	
	@XmlAttribute(name="Name")
	private String Name;

	@XmlElement(name="Value")
	private String Value;
    
    public Field() {
		super();	
	}
	public String getName ()
    {
        return Name;
    }   
    public void setName (String Name)
    {
        this.Name = Name;
    }
    public String getValue ()
    {
        return Value;
    }   
    public void setValue (String Value)
    {
        this.Value = Value;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Name = "+Name+", Value = "+Value+"]";
    }
}
