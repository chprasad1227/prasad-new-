package com.aexp.cicdmainframe.hpuftintegration.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BuildVerificationRunDetailsResponse {
	
	@XmlElement(name = "Entities")
	private Entities Entities;

	
	public BuildVerificationRunDetailsResponse() {
		super();
		
	}

	public Entities getEntities() {
		return Entities;
	}

	public void setEntities(Entities entities) {
		Entities = entities;
	}




	@Override
	public String toString() {
		return "StartRunProcessResponse [Entities=" + Entities + "]";
	}
}
