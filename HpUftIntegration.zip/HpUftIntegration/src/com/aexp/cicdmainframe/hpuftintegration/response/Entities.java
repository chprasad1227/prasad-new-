package com.aexp.cicdmainframe.hpuftintegration.response;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Entities")
public class Entities implements Serializable
{
	private static final long serialVersionUID = 1L;

	@XmlAttribute(name = "TotalResults")
	private String TotalResults;

	@XmlElement(name = "Entity")
	private List<Entity> Entity;

	public Entities() {
		super();		
	}
	public String getTotalResults ()
	{
		return TotalResults;
	}	
	public void setTotalResults (String TotalResults)
	{
		this.TotalResults = TotalResults;
	}
	public List<Entity> getEntity() {
		return Entity;
	}
	public void setEntity(List<Entity> entity) {
		Entity = entity;
	}
	@Override
	public String toString()
	{
		return "Entities [TotalResults = "+TotalResults+", Entity = "+Entity+"]";
	}
}
