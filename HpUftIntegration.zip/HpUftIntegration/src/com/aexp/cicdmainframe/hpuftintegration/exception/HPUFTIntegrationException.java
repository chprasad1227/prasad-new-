package com.aexp.cicdmainframe.hpuftintegration.exception;

public class HPUFTIntegrationException extends RuntimeException {	

	/**
	 * 
	 */
	private static final long serialVersionUID = -8834819585396325995L;

	public HPUFTIntegrationException() {
		super();
	}

	/*public HPUFTIntegrationException(String errorCode,String message) {
		super(errorCode, message);
	}*/ 
	public HPUFTIntegrationException(String message, Throwable cause) {
		super(message, cause);
	}

	public HPUFTIntegrationException(String message) {
		super(message);
	}

	public HPUFTIntegrationException(Throwable cause) {
		super(cause);
	}

}
