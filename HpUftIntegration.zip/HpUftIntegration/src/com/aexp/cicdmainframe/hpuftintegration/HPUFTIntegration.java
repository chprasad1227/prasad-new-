package com.aexp.cicdmainframe.hpuftintegration;

import java.util.Properties;

public interface HPUFTIntegration {
	
	String execute(Properties inputProperties, Properties outputProperties);
	
}
