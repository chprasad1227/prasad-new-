package com.aexp.cicdmainframe.hpuftintegration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.aexp.cicdmainframe.hpuftintegration.authetication.AuthenticationDetails;
import com.aexp.cicdmainframe.hpuftintegration.bvssuite.BuildVerificationRunDetails;
import com.aexp.cicdmainframe.hpuftintegration.bvssuite.BuildVerificationSuiteExecution;
import com.aexp.cicdmainframe.hpuftintegration.common.HPUFTIntegrationConstants;
import com.aexp.cicdmainframe.hpuftintegration.common.PropertiesCache;
import com.aexp.cicdmainframe.hpuftintegration.exception.HPUFTIntegrationException;
import com.aexp.cicdmainframe.hpuftintegration.response.BuildVerificationRunDetailsResponse;
import com.aexp.cicdmainframe.hpuftintegration.response.BuildVerificationSuiteExecutionResponse;
import com.aexp.cicdmainframe.hpuftintegration.response.Entities;
import com.aexp.cicdmainframe.hpuftintegration.response.Entity;
import com.aexp.cicdmainframe.hpuftintegration.response.Field;
import com.aexp.cicdmainframe.hpuftintegration.response.Fields;

public class StartBuildVerificationSuite implements HPUFTIntegration {
	
		
	private static StartBuildVerificationSuite buildVerificationSuite;
	
	static final Logger logger = Logger.getLogger(StartBuildVerificationSuite.class);
	
	/**
	 * @param 
	 * @param 
	 * @param 
	 * @return 
	 */
	
	public String execute(Properties inputProperties, Properties outputProperties) {	
		
		PropertiesCache porpCache = PropertiesCache.getInstance();		
		String domainName = inputProperties.getProperty(HPUFTIntegrationConstants.DOMAIN_NAME);	
		String projectName = inputProperties.getProperty(HPUFTIntegrationConstants.PROJECT_NAME);
				
		if(domainName!=null && projectName!=null ) {
			 logger.info(" domain....."+domainName);
			 logger.info(" projectName....."+projectName);					
			if(porpCache.containsKey(HPUFTIntegrationConstants.DOMAIN_NAME) == false){
				porpCache.setProperty(HPUFTIntegrationConstants.DOMAIN_NAME, domainName);
			}
			if(porpCache.containsKey(HPUFTIntegrationConstants.PROJECT_NAME) == false){
				porpCache.setProperty(HPUFTIntegrationConstants.PROJECT_NAME, projectName);
			}
			
		} else {			
			throw new HPUFTIntegrationException("Domian or Project is null");			
		}
		String bvsRunStatus = null;
		
		try {
			//1. Authentication: get Authentication 
			logger.info("Step 1. Authentication---------------: ");
			AuthenticationDetails authenticationDetails = AuthenticationDetails.getInstance();
			Map<String, String>authentcateDetailsMap = authenticationDetails.getAuthenticateDetails();
			
			String bvsRunId =null;
			/* 7. Get the BVS Run Id from the Output Properties  */
			bvsRunId = (String) inputProperties.get("bvsRunId");
			logger.info("bvsRunId.........."+bvsRunId);
			logger.debug("bvsRunId......"+bvsRunId);
			
			/* 7. Invoking the  Build Verification Suite Execution  Service */		
			BuildVerificationSuiteExecutionResponse buildVerificationSuiteExecutionResponse = null;	
			BuildVerificationSuiteExecution bvsExecution = BuildVerificationSuiteExecution.getInstance();
			/* Get Status of Build Verification Suite Execution 
			 * <Field Name="state"><Value>Finished</Value>
			 * <Field Name="completed-successfully"><Value>N</Value>
			 *  */
			if(bvsRunId!=null) {
				buildVerificationSuiteExecutionResponse = bvsExecution.doGetBuildVerificationSuiteExecutionStatus(domainName, projectName, bvsRunId,authentcateDetailsMap);
				/* Read the Status of the Procedure/BVS runId from the Response received from buildVerificationSuiteExecution Service.
				 * And Store in the Output properties file: ("BVS_EXECUTION_STATUS", statusValue)
				 *   */
				if(buildVerificationSuiteExecutionResponse!=null && buildVerificationSuiteExecutionResponse.getEntity()!=null) {
					String buildVerificationSuite_status = null;
					Entity entity = buildVerificationSuiteExecutionResponse.getEntity();
					Fields fields = entity.getFields();
					if (fields!=null) {
						for(Field field : fields.getField()) {
							if(field.getName().equalsIgnoreCase("state")) {
								buildVerificationSuite_status = field.getValue();							
								logger.info("buildVerificationSuiteExecutionStatus >> state >> field name "+field.getName());
								logger.info("buildVerificationSuiteExecutionStatus >> state >> field value "+field.getValue());							
								outputProperties.put("BVS_EXECUTION_STATE", field.getValue());							
							} else if(field.getName().equalsIgnoreCase("completed-successfully")) {
								buildVerificationSuite_status = field.getValue();							
								logger.info("buildVerificationSuiteExecutionStatus >> status >> field name "+field.getName());
								logger.info("buildVerificationSuiteExecutionStatus >> status >> field value "+field.getValue());
								outputProperties.put("BVS_EXECUTION_STATUS", buildVerificationSuite_status);
							}
						}
					}
				}
				BuildVerificationRunDetailsResponse buildVerificationRunDetailsResponse = null;			
				String buildVerificationRun_status = null;	
				BuildVerificationRunDetails buildVerificationRunDetails = BuildVerificationRunDetails.getInstance();
				
				buildVerificationRunDetailsResponse = buildVerificationRunDetails.doGetBuildVerificationRunDetails(domainName, projectName, bvsRunId,authentcateDetailsMap);
				/* Read the RUN Status of the Procedure/BVS runId from the Response received from Build Verification Run DETAILS Service.
				 * And Store in the Output properties file: ("BVS_RUN_STATUS", statusValue)
				 *   */
				if(buildVerificationRunDetailsResponse!=null) {
					Entities entities = buildVerificationRunDetailsResponse.getEntities();
					logger.info("Total Results   "+entities.getTotalResults());
					outputProperties.put("TOTAL_ENTITIES", entities.getTotalResults());
					List<Entity> entityList = entities.getEntity();
					if (entityList!=null) {
						for(int i =0; i<entityList.size(); i++) {
							Entity e = entityList.get(i);
							logger.info("Entity Type  "+e.getType());
							if(e.getFields()!=null) {
								Fields fields = e.getFields();								
								for(Field field : fields.getField()) {    
							        logger.info(" Build Verification Run  field name "+field.getName());
							        logger.info(" Build Verification Run field value "+field.getValue());
							        buildVerificationRun_status = field.getValue();
							        if(field.getName().equalsIgnoreCase("state")) {
							        bvsRunStatus = buildVerificationRun_status;								        
							        outputProperties.put("ENTITY_"+(i+1)+"_BVS_RUN_STATUS", field.getValue());
							        break;
							        }										
								}
							}							
						}
					}
				}
			} else {				
				throw new HPUFTIntegrationException("BVS RUN ID is not available..");
			}
			
		}catch(Exception e) {
			throw new HPUFTIntegrationException("Exception while processing execute() in StartBuildVerificationSuite.."+e);
		
		}
		return bvsRunStatus;
	}
	
	/**
	 * 
	 * 
	 * 
	 * @param 
	 * @param 
	 * @param 
	 * @return 
	 */
	public static void main(String[] args) {
		if (args.length < 2) {
			throw new RuntimeException(
					"Unexpected number of plugin arguments.  Expecting: InputPropertyFile OutputPropertyFile");
		}
		String inputPropertiesPath = args[0];
		String outputPropertiesPath = args[1];		
		String certificateDetailsPath = null;
		Properties inputProperties = new Properties();
		Properties outputProperties = new Properties();
		try {			
			if(args.length == 3) {				
				System.setProperty("certificateDetailsPath", args[2]);
			}
			PropertiesCache porpCache = PropertiesCache.getInstance();
			
			
			inputProperties.load(new FileInputStream(new File(inputPropertiesPath)));
			outputProperties = porpCache.readPropertiesFile(outputPropertiesPath);
			
			buildVerificationSuite = new StartBuildVerificationSuite();	
			buildVerificationSuite.execute(inputProperties, outputProperties);
			
			logger.info("StartBuildVerificationSuite Main Ends..");
		} catch (Exception e) {	
			outputProperties.put("StartBuildVerificationSuiteException", e.getMessage());
			e.printStackTrace();
		}
		finally {
			OutputStream outputFile;
			try {
				outputFile = new FileOutputStream(outputPropertiesPath);
				outputProperties.store(outputFile, null);
			} catch (IOException e) {		
				e.printStackTrace();
			}
		}
	}

}
