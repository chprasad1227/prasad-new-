package com.aexp.cicdmainframe.hpuftintegration.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeSet;

import org.apache.log4j.Logger;
 
public class PropertiesCache
{
	static final Logger logger = Logger.getLogger(PropertiesCache.class);
	private static PropertiesCache INSTANCE;
	private  Properties configProp;
	private static String propertyFile =  "app.properties";
	
	private PropertiesCache()
	{
	
		loadProperties(propertyFile);
	}

	

	public static PropertiesCache getInstance()
	{
		if(INSTANCE==null) {
			INSTANCE = new PropertiesCache();
		}
		return INSTANCE;
	}


	public String getProperty(String key){
		return configProp.getProperty(key);
	}
	
	public void setProperty(String key, String value){
		  configProp.setProperty(key, value);
	}

	

	public boolean containsKey(String key){
		return configProp.containsKey(key);
	}


	public void loadProperties(String propertyFile) {			
		try {
			if(configProp==null) {
				configProp = new Properties();
				InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(propertyFile);
				if (inputStream != null) {
					logger.info("loading properties file.. ");
					logger.debug("loading properties file.. ");
					configProp.load(inputStream);					
					for (final Entry<Object, Object> entry : configProp.entrySet()) {
						System.setProperty(entry.getKey().toString(), entry.getValue().toString());
					}
				} 
			}
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Read a Java properties file and return it as a Properties object.
	 */
	public  Properties readPropertiesFile(String filename) throws IOException
	{
	  Properties properties = new Properties() {
		  /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		  public synchronized Enumeration<Object> keys() {
		        return Collections.enumeration(new TreeSet<Object>(super.keySet()));
		    }
	  };	  
	  properties.load(new FileInputStream(filename));
	  return properties;
	}
}
