package com.aexp.cicdmainframe.hpuftintegration.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

import org.apache.log4j.Logger;

import com.aexp.cicdmainframe.hpuftintegration.response.Entity;
import com.aexp.cicdmainframe.hpuftintegration.response.Field;
import com.aexp.cicdmainframe.hpuftintegration.response.Fields;

public class HPUFTIntegrationUtil {
	static final Logger logger = Logger.getLogger(HPUFTIntegrationUtil.class);
	
	private static Map<String, String> authenticationMap = null;
	private static HPUFTIntegrationUtil INSTANCE;
	
	
	public HPUFTIntegrationUtil() {
		
	}	
	public static HPUFTIntegrationUtil getInstance() { 
		if(INSTANCE==null) {
			INSTANCE = new HPUFTIntegrationUtil();
		}
		return INSTANCE;
	}
	
	public static Map<String, String> getAuthenticationMap() {
		return authenticationMap;
	}
	
	public static void setAuthenticationMap(Map<String, String> authenticationMap) {
		HPUFTIntegrationUtil.authenticationMap = authenticationMap;
	}
		
	public Entity createRequestEntity() {
		Entity requestEntity = new Entity();	
		Field field1 = new Field();		
		field1.setName("duration");
		field1.setValue("100");

		Field field2 = new Field();		
		field2.setName("vudsMode");
		field2.setValue("false");

		Field field3 = new Field();
		field3.setName("reservationId");
		field3.setValue("-1");

		Fields fields = new Fields();
		fields.setField(Arrays.asList(field1,field2,field3));
		requestEntity.setFields(fields);
		return requestEntity;
	}
	
	/**
	 * SSLContext getSSLContext().
	 * 
	 * It takes the keystore_file as input 
	 * and generates the SSLContext
	 * @return SSLContext
	 */
	public SSLContext getSSLContext() {
		SSLContext context = null;
		try {			
			String pKeyFilePath = System.getProperty("keystore_file");			
			String certificateDetailsPathFromArg = "";
			String pKeyPassword = System.getProperty("keystore_password");	 
			File argKeyStoreFile = null;
			File resourceFile = null;
			File localFile = null;
			InputStream keyInput = null;
			
			resourceFile=new File(this.getClass().getClassLoader().getResource(pKeyFilePath).getFile());
			logger.info("configFile "+resourceFile.exists());
			logger.debug("configFile "+resourceFile.exists());
			if(resourceFile!=null && resourceFile.exists()) {
				logger.info("Reading Key Store file from classpth resources..");
				logger.debug("Reading Key Store file from classpth resources..");
				keyInput  = new FileInputStream(resourceFile);
			} else {
				String localPath = "C:\\Users\\schalav\\Downloads\\Certificate\\epegtrustcert\\epegtrustcert.pfx";
				localFile = new File(localPath);
				if(localFile!=null && localFile.exists()) {
					logger.info("Reading Key Store file from Local directory...");
					keyInput  = new FileInputStream(localFile);
				}  else {
					certificateDetailsPathFromArg = System.getProperty("certificateDetailsPath");
					if(certificateDetailsPathFromArg!=null){
						argKeyStoreFile = new File(certificateDetailsPathFromArg);
						logger.info("Reading Key Store file from Args...");
						logger.debug("Reading Key Store file from Args...");
						keyInput  = new FileInputStream(argKeyStoreFile);						
					}					
				}
			}
			if(keyInput!=null) {
				KeyStore keyStore = KeyStore.getInstance("pkcs12");	
				if(keyStore==null){
				 keyStore = KeyStore.getInstance("jks");
				}
				keyStore.load(keyInput, pKeyPassword.toCharArray());	
				keyInput.close();
				KeyManagerFactory keyManagerFactory;
				try {
					keyManagerFactory = KeyManagerFactory.getInstance("IbmX509", "IBMJSSE2");
				} catch (NoSuchAlgorithmException nsae ) {
					keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
				}
				catch (NoSuchProviderException nspe) {
					keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
				}
				
				if (keyManagerFactory!=null) {
					keyManagerFactory.init(keyStore, pKeyPassword.toCharArray());
					//tmf.init(keyStore);
					context = SSLContext.getInstance("TLS");
					context.init(keyManagerFactory.getKeyManagers(), null, new SecureRandom());
			
				}
				else{
					throw new RuntimeException("keyManagerFactory is null");
				}
					}		
			return context;

		} catch (Exception e) {		
			e.printStackTrace();
		}
		return context;
	}
}