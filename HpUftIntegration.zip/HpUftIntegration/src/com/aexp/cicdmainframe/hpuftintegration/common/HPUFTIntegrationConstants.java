package com.aexp.cicdmainframe.hpuftintegration.common;

public interface HPUFTIntegrationConstants {
	
	public static final String CREDENTIALS = "credentials";
	
	public static final String USERNAME = "username";	
	public static final String PASSWORD = "password";
	
	public static final String DOMAIN_NAME = "domainName";
	public static final String PROJECT_NAME = "projectName";
	public static final String BVS_ID = "bvsId";
	
	public static final String AUTHENTICATION_URL = "auth.url";
	
	public static final String  LWSSO_COOKIE_VALUE="LWSSO_COOKIE_VALUE";
	
	
	public static final String START_RUN_PROCEDURE_URL ="start.run.procedure.url";
	public static final String BUILD_VERIFICATION_URL ="build_verification.url";
	
	

}
