package com.aexp.cicdmainframe.hpuftintegration.bvssuite;

import java.io.StringReader;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;

import com.aexp.cicdmainframe.hpuftintegration.HPUFTIntegration;
import com.aexp.cicdmainframe.hpuftintegration.common.HPUFTIntegrationConstants;
import com.aexp.cicdmainframe.hpuftintegration.common.HPUFTIntegrationUtil;
import com.aexp.cicdmainframe.hpuftintegration.common.PropertiesCache;
import com.aexp.cicdmainframe.hpuftintegration.response.BuildVerificationSuiteExecutionResponse;
import com.aexp.cicdmainframe.hpuftintegration.response.Entity;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

public class BuildVerificationSuiteExecution {

	private static BuildVerificationSuiteExecution buildVerificationSuite;
	static final Logger logger = Logger.getLogger(BuildVerificationSuiteExecution.class);
	

	private BuildVerificationSuiteExecution() {
		
	}
	public static BuildVerificationSuiteExecution getInstance() {
		if(buildVerificationSuite==null)
			buildVerificationSuite= new BuildVerificationSuiteExecution();
		return buildVerificationSuite;
	}
	
	/**
	 * BuildVerificationSuiteExecutionResponse doGetBuildVerificationSuiteExecutionStatus(String domainName, String projectName, String bvsId)  
	 * throws RuntimeException 
	 * This method  takes DomainName, ProjectName and BvsRunId
	 * and Invokes the Build Verification Suite Execution Service  
	 * Response contains Entities and its Fields
	 * Value of Field �completed-successfully� can be used to get the status of Build Verification Suite execution 
	 * 
	 * 
	 * @param domainName
	 * @param projectName
	 * @param bvsRunId
	 * @param authentcateDetailsMap 
	 * @return BuildVerificationSuiteExecutionResponse
	 * @throws RuntimeException
	 */
	public BuildVerificationSuiteExecutionResponse doGetBuildVerificationSuiteExecutionStatus(String domainName, String projectName, String bvsRunId, Map<String, String> authentcateDetailsMap)  throws RuntimeException {		
		logger.info("=======Step 7. BuildVerificationSuiteExecution==================");
		BuildVerificationSuiteExecutionResponse buildVerificationSuiteResponse = null;
		String bvsURL = PropertiesCache.getInstance().getProperty(HPUFTIntegrationConstants.BUILD_VERIFICATION_URL);		
		String cookieValue = authentcateDetailsMap.get(HPUFTIntegrationConstants.LWSSO_COOKIE_VALUE);			
		String credentials = authentcateDetailsMap.get(HPUFTIntegrationConstants.CREDENTIALS);
		logger.info("BuildVerificationSuiteExecution->domainName "+domainName);
		logger.info("BuildVerificationSuiteExecution->projectName "+projectName);
		logger.info("BuildVerificationSuiteExecution->bvsRunId "+bvsRunId);	

		//Client restClient = Client.create();
		ClientConfig clientConfig = new DefaultClientConfig();
		
		/* get the  SSL context 
		 * and set the SSLContext rest client*/
		SSLContext context =HPUFTIntegrationUtil.getInstance().getSSLContext();
		HostnameVerifier hostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier();
		clientConfig.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(hostnameVerifier, context));		
		Client restClient = Client.create(clientConfig);		
		
		/*Invoking the Service.. */
		WebResource webResource = restClient.resource(bvsURL)
				.path("domains").path(domainName)
				.path("projects").path(projectName)
				.path("procedure-runs").path(bvsRunId);
				
		logger.info("BuildVerificationSuiteExecution URL: " + webResource.getURI().toString());  
		/*try {
			Thread.sleep(100000);
		} catch (InterruptedException e2) {			
			e2.printStackTrace();
		}*/
		ClientResponse response;
		try {
			response = webResource.accept("application/xml")
					.header("Authorization", "Basic " + credentials)
					.header("Cookie",cookieValue)
					.get(ClientResponse.class);
		
		logger.info("response.getStatus()..."+response.getStatus());
		/*Read the response from  Service.. */
		if(response.getStatus() != 200){			
			logger.error("BuildVerificationSuiteExecution Unable to connect to the server"+response.getStatus());
			throw new RuntimeException("BuildVerificationSuiteExecution Unable to connect to the server"+response.getStatus());
		}
		//read the data 
		if(response.getStatus()== ClientResponse.Status.OK.getStatusCode()) {
			String responseInXMLString = response.getEntity(String.class);
			Entity entity = null;
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(Entity.class);
				Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				StringReader reader = new StringReader(responseInXMLString);
				StreamSource streamSource = new StreamSource(reader);
				JAXBElement<Entity> je = unmarshaller.unmarshal(streamSource, Entity.class);
				entity = (Entity) je.getValue();
			} catch (JAXBException jaxbe) {					
				logger.error("Exception while unmarshalling the response",jaxbe);
				entity = response.getEntity(Entity.class);
			}
			logger.info("BuildVerificationSuiteExecution entity....."+entity);
			if(entity!=null) {
				logger.info("entity type....."+entity.getType());
				buildVerificationSuiteResponse = new BuildVerificationSuiteExecutionResponse();
				buildVerificationSuiteResponse.setEntity(entity);
			}

		}
		} catch (Exception e1) {			
			e1.printStackTrace();
		}
		return buildVerificationSuiteResponse;		
	}

}
