package com.aexp.cicdmainframe.hpuftintegration.bvssuite;

import java.io.StringReader;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.ws.rs.core.MultivaluedMap;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;

import com.aexp.cicdmainframe.hpuftintegration.HPUFTIntegration;
import com.aexp.cicdmainframe.hpuftintegration.common.HPUFTIntegrationConstants;
import com.aexp.cicdmainframe.hpuftintegration.common.HPUFTIntegrationUtil;
import com.aexp.cicdmainframe.hpuftintegration.response.BuildVerificationRunDetailsResponse;
import com.aexp.cicdmainframe.hpuftintegration.response.Entities;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class BuildVerificationRunDetails {

	static final Logger logger = Logger.getLogger(BuildVerificationRunDetails.class);
	private static BuildVerificationRunDetails buildVerificationRun;
	
	private BuildVerificationRunDetails() {
		
	}
	public static BuildVerificationRunDetails getInstance() {
		if(buildVerificationRun==null)
			buildVerificationRun= new BuildVerificationRunDetails();
		return buildVerificationRun;
	}
	
	/**
	 * BuildVerificationRunDetailsResponse doGetBuildVerificationRunDetails(String domainName,String projectName,String bvsId)
	 * This takes the DomainName, ProjectName and BVSRunId. 
	 * Invokes the BuildVerificationRunDetails Service.
	 * Response contains Entities and its fields.
	 * Value of Field �state� can be used to get the status of the BVS Run
	 * @param domainName
	 * @param projectName
	 * @param bvsRunId
	 * @param authentcateDetailsMap 
	 * @return
	 */
	public BuildVerificationRunDetailsResponse doGetBuildVerificationRunDetails(String domainName,String projectName,String bvsRunId, Map<String, String> authentcateDetailsMap) {
		logger.info("======= 8. BuildVerificationRunDetails for Domain, Project and Entity/BVSId==============");		
		BuildVerificationRunDetailsResponse buildVerificationRunResponse = null;
		String startRunProcedureURL = System.getProperty(HPUFTIntegrationConstants.BUILD_VERIFICATION_URL);
		String cookieValue = authentcateDetailsMap.get(HPUFTIntegrationConstants.LWSSO_COOKIE_VALUE);			
		String credentials = authentcateDetailsMap.get(HPUFTIntegrationConstants.CREDENTIALS);		
		logger.info("BuildVerificationRunDetails->domainName "+domainName);
		logger.info("BuildVerificationRunDetails->projectName "+projectName);
		logger.info("BuildVerificationRunDetails->bvsRunId "+bvsRunId);	

		
		ClientConfig clientConfig = new DefaultClientConfig();	
		SSLContext context =HPUFTIntegrationUtil.getInstance().getSSLContext();
		HostnameVerifier hostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier();
		clientConfig.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(hostnameVerifier, context));
		Client restClient = Client.create(clientConfig);
		
		MultivaluedMap<String, String> params = new MultivaluedMapImpl();
		params.add("query", "{procedure-run["+bvsRunId+"]}"); 

		WebResource webResource = restClient.resource(startRunProcedureURL)
				.path("domains").path(domainName)
				.path("projects").path(projectName)
				.path("procedure-testset-instance-runs")
				.queryParams(params); //query={procedure-run['< BVS Run ID>']}
		logger.info("BuildVerificationRunDetails URL: " + webResource.getURI().toString());		
		
		ClientResponse response = webResource.accept("application/xml")
				.header("Authorization", "Basic " + credentials)
				.header("Cookie",cookieValue)
				.get(ClientResponse.class);

		if(response.getStatus() != 200){
			System.err.println("Unable to connect to the server");
			logger.error("BuildVerificationRunDetails Unable to connect to the server"+response.getStatus());
			throw new RuntimeException("BuildVerificationRunDetails Unable to connect to the server"+response.getStatus());
		}		
		//read the data 
		if(response.getStatus()==201 || response.getStatus()== ClientResponse.Status.OK.getStatusCode()) {
			try {
				String responseInXMLString = response.getEntity(String.class);				
				JAXBContext jaxbContext = JAXBContext.newInstance(Entities.class);
				Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				StringReader reader = new StringReader(responseInXMLString);
				StreamSource streamSource = new StreamSource(reader);
				JAXBElement<Entities> je = unmarshaller.unmarshal(streamSource, Entities.class);
				Entities entityResponse  = (Entities) je.getValue();

				logger.info("Build Verification Run entityResponse....."+entityResponse);
				if(entityResponse!=null) {
					logger.info("Build Verification Run Total entities....."+entityResponse.getTotalResults());
					buildVerificationRunResponse = new BuildVerificationRunDetailsResponse();
					buildVerificationRunResponse.setEntities(entityResponse);					
				}	
			} catch (Exception e) {				
				e.printStackTrace();
			}
		}
		return buildVerificationRunResponse;		
	}

}
