package plugin;

import groovy.json.JsonBuilder
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper
import java.io.File;
import java.util.Properties;


class BaselineRefresh {

	public static void main( java.lang.String[] args ) {
def String rtc_mod="rtc_mod"
		final def inProps = new File(args[args.length-2]);


		final def outProps = new File(args[args.length-1]);
		inProps = new Properties();
			final def inputPropsFile = new File(args[args.length-2]);
			def inputPropsStream = new FileInputStream(inputPropsFile);
			inProps.load(inputPropsStream);

			
			def outPropsFilename = args[args.length-1]
			outProps = new Properties();
			def outputPropsStream = new FileOutputStream(outPropsFilename);
			

			
		def json = new JsonBuilder();



		def rtc_data = new groovy.json.JsonSlurper().parseText(inProps.getProperty("rtc.data"));
		
		rtc_data.each {String key, def value ->
			String featureId = value.featureId;

			if(!featureId.isEmpty()) {
				json.setAndGetContent(key, value)
				println json.toPrettyString()
				outProps.setProperty(rtc_mod,json.toPrettyString())
			}
		}
		outProps.store(outputPropsStream, "out props")
	
	}
}
